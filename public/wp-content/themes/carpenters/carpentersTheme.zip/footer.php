		<div id="footer">
			Oregon/SW Washington Carpenters Local Union No. 156<br>
			276 Warner-Milne Road Oregon City, OR 97045 503/656-7716 <a href="mailto:156@northwestcarpenters.org" alt="email 156@northwestcarpenters.org">156@northwestcarpenters.org</a><br>
			&copy; <a href="http://www.ubc156.org">www.ubc156.org</a> <?php echo date("Y"); ?>
		</div>
	</div>
</div>	
<?php get_template_part('includes/scripts'); ?>
<?php wp_footer(); ?>	
